﻿//anderson

#include <iostream>
#include <cstdlib>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

//used for image loading
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

//glm math
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

//camera header file
#include "CameraFile.h"
//meshes header file
#include "Meshes.h"

using namespace std;

//shader macro
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

namespace
{
	//window title
	const char* const WINDOW_TITLE = "Anderson Final Project";

	//window size
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;

	struct GLMesh
	{
		//vertex array object
		GLuint vao;
		//vertex buffer objects
		GLuint vbos[2];
		//vertices
		GLuint nVertices;
		//indices
		GLuint nIndices;
	};

	// main window
	GLFWwindow* gWindow = nullptr;
	//shader
	GLuint gProgramId;
	//Camera object
	Camera gCamera(glm::vec3(0.0f, 2.0f, 2.0f));
	//texture id
	GLuint gTextureGlass;
	GLuint gTextureBottleTop;
	GLuint gTextureStove;
	GLuint gTextureBox;
	GLuint gTextureOrange;
	GLuint gTextureHat;
	GLuint gTextureBottleTop2;
	GLuint gTextureBottleLabel;
	GLuint gTextureHatStrap;
	GLuint gTextureContainerTop;

	bool extraTex = false;

	//Meshes object
	Meshes meshes;

	bool perspective = true;

	bool lightOn = true;

	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// timing for camera
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;


	


}

//vertex shader source
const GLchar* vertexShaderSource = GLSL(440,

	layout(location = 0) in vec3 vertexPosition; 
layout(location = 1) in vec3 vertexNormal;
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexFragmentNormal;
out vec3 vertexFragmentPos;
out vec2 vertexTextureCoordinate;

//variables
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
	gl_Position = projection * view * model * vec4(vertexPosition, 1.0f);

	vertexFragmentPos = vec3(model * vec4(vertexPosition, 1.0f));

	vertexFragmentNormal = mat3(transpose(inverse(model))) * vertexNormal;
	vertexTextureCoordinate = textureCoordinate;
}
);
//fragment shader source
const GLchar* fragmentShaderSource = GLSL(440,

	in vec3 vertexFragmentNormal;
in vec3 vertexFragmentPos;
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor;


//variables
uniform vec4 objectColor;
uniform vec3 ambientColor;
uniform vec3 light1Color;
uniform vec3 light1Position;
uniform vec3 light2Color;
uniform vec3 light2Position;
uniform vec3 viewPosition;

uniform sampler2D uTexture;
uniform sampler2D uTexture2;
//uniform vec4 objectColor;
uniform bool multipleTextures;

uniform vec2 uvScale;

uniform bool ubHasTexture;
//ambient light strength
uniform float ambientStrength = 1.0f;
uniform float specularIntensity1 = 1.0f;
uniform float highlightSize1 = 8.0f;
uniform float specularIntensity2 = 0.8f;
uniform float highlightSize2 = 16.0f;


void main()
{


	//ambient light calculation
	vec3 ambient = ambientStrength * ambientColor;

	//diffuse light calculation
	vec3 norm = normalize(vertexFragmentNormal);
	vec3 light1Direction = normalize(light1Position - vertexFragmentPos);
	float impact1 = max(dot(norm, light1Direction), 0.0);
	vec3 diffuse1 = impact1 * light1Color;

	vec3 light2Direction = normalize(light2Position - vertexFragmentPos);
	float impact2 = max(dot(norm, light2Direction), 0.0);
	vec3 diffuse2 = impact2 * light2Color; 

	//specular light calculation
	vec3 viewDir = normalize(viewPosition - vertexFragmentPos);
	vec3 reflectDir1 = reflect(-light1Direction, norm);
	//Calculate specular component
	float specularComponent1 = pow(max(dot(viewDir, reflectDir1), 0.001), highlightSize1);
	vec3 specular1 = specularIntensity1 * specularComponent1 * light1Color;

	vec3 reflectDir2 = reflect(-light2Direction, norm);
	//Calculate specular component
	float specularComponent2 = pow(max(dot(viewDir, reflectDir2), 0.0), highlightSize2);
	vec3 specular2 = specularIntensity2 * specularComponent2 * light2Color;
	
	//calculate phong
	vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);
	vec3 phong1;
	vec3 phong2;



	fragmentColor = texture(uTexture, vertexTextureCoordinate * uvScale);
	if (multipleTextures) {
		vec4 extraTexture = texture(uTexture2, vertexTextureCoordinate);
		//has a texture
		if (ubHasTexture == true) {
			phong1 = (ambient + diffuse1 + specular1) * extraTexture.xyz;
			phong2 = (ambient + diffuse2 + specular2) * extraTexture.xyz;
		}

		if (extraTexture.a != 0.0) {
			if (extraTexture.a < 0.1)
				discard;
			fragmentColor = vec4(phong1 + phong2, 1.0);
		}

	}
	else if (!multipleTextures) {
		//has a texture
		if (ubHasTexture == true) {
			phong1 = (ambient + diffuse1 + specular1) * textureColor.xyz;
			phong2 = (ambient + diffuse2 + specular2) * textureColor.xyz;
		}
		//does not have a texture
		else {
			phong1 = (ambient + diffuse1 + specular1) * objectColor.xyz;
			phong2 = (ambient + diffuse2 + specular2) * objectColor.xyz;
		}
		if (fragmentColor.a != 0.0) {
			if (fragmentColor.a < 0.1)
				discard;
			fragmentColor = vec4(phong1 + phong2, 1.0);
		}
	}
	

}
);

//functions
bool UInitialize(int, char* [], GLFWwindow** window);
//window resize
void UResizeWindow(GLFWwindow* window, int width, int height);
//process inputs
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
//render
void URender();
//create/destroy shader
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
//create/destroy texture
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);

//main function
int main(int argc, char* argv[])
{
	if (!UInitialize(argc, argv, &gWindow))
		return EXIT_FAILURE;

	//create meshes
	meshes.CreateMeshes();

	//create shader check
	if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
		return EXIT_FAILURE;

	//load texture
	const char* texFilename = "resources/glass.png";

	if (!UCreateTexture(texFilename, gTextureGlass)) {
		cout << "Failed to load texture " << texFilename << endl;
		return EXIT_FAILURE;
	}

	//load 2nd texture
	texFilename = "resources/bottletopTexture.png";

	if (!UCreateTexture(texFilename, gTextureBottleTop)) {
		cout << "Failed to load texture " << texFilename << endl;
		return EXIT_FAILURE;
	}

	//3rd
	texFilename = "resources/stoveTexture.png";

	if (!UCreateTexture(texFilename, gTextureStove)) {
		cout << "Failed to load texture " << texFilename << endl;
		return EXIT_FAILURE;
	}

	//4th
	texFilename = "resources/glass_try.png";

	if (!UCreateTexture(texFilename, gTextureBox)) {
		cout << "Failed to load texture " << texFilename << endl;
		return EXIT_FAILURE;
	}

	//5th
	texFilename = "resources/orange.png";

	if (!UCreateTexture(texFilename, gTextureOrange)) {
		cout << "Failed to load texture " << texFilename << endl;
		return EXIT_FAILURE;
	}

	//6th
	texFilename = "resources/blackFabric.png";

	if (!UCreateTexture(texFilename, gTextureHat)) {
		cout << "Failed to load texture " << texFilename << endl;
		return EXIT_FAILURE;
	}

	//7th
	texFilename = "resources/bottletopTextureTop.png";

	if (!UCreateTexture(texFilename, gTextureBottleTop2)) {
		cout << "Failed to load texture " << texFilename << endl;
		return EXIT_FAILURE;
	}

	//8th
	texFilename = "resources/label.png";

	if (!UCreateTexture(texFilename, gTextureBottleLabel)) {
		cout << "Failed to load texture " << texFilename << endl;
		return EXIT_FAILURE;
	}
	//9th
	texFilename = "resources/hatStrap.png";

	if (!UCreateTexture(texFilename, gTextureHatStrap)) {
		cout << "Failed to load texture " << texFilename << endl;
		return EXIT_FAILURE;
	}

	//10th
	texFilename = "resources/containerTop.png";

	if (!UCreateTexture(texFilename, gTextureContainerTop)) {
		cout << "Failed to load texture " << texFilename << endl;
		return EXIT_FAILURE;
	}

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTextureGlass);

	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, gTextureBottleTop);

	glActiveTexture(GL_TEXTURE2);
	glBindTexture(GL_TEXTURE_2D, gTextureStove);

	glActiveTexture(GL_TEXTURE3);
	glBindTexture(GL_TEXTURE_2D, gTextureBox);

	glActiveTexture(GL_TEXTURE4);
	glBindTexture(GL_TEXTURE_2D, gTextureOrange);

	glActiveTexture(GL_TEXTURE5);
	glBindTexture(GL_TEXTURE_2D, gTextureHat);

	glActiveTexture(GL_TEXTURE6);
	glBindTexture(GL_TEXTURE_2D, gTextureBottleTop2);

	glActiveTexture(GL_TEXTURE7);
	glBindTexture(GL_TEXTURE_2D, gTextureBottleLabel);

	glActiveTexture(GL_TEXTURE8);
	glBindTexture(GL_TEXTURE_2D, gTextureHatStrap);

	glActiveTexture(GL_TEXTURE9);
	glBindTexture(GL_TEXTURE_2D, gTextureContainerTop);



	//set background color
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	gCamera.Position = glm::vec3(0.0f, 1.0f, 16.0f);
	gCamera.Front = glm::vec3(0.0, 0.0, -1.0f);
	gCamera.Up = glm::vec3(0.0, 1.0, 0.0);

	//while loop render
	while (!glfwWindowShouldClose(gWindow))
	{
		//pre-frame timing
		float currentFrame = glfwGetTime();
		gDeltaTime = currentFrame - gLastFrame;
		gLastFrame = currentFrame;

		//input
		UProcessInput(gWindow);

		URender();

		glfwPollEvents();
	}

	// Release mesh data
	meshes.DestroyMeshes();

	UDestroyShaderProgram(gProgramId);

	//destroy texture data
	UDestroyTexture(gTextureGlass);
	UDestroyTexture(gTextureBottleTop);
	UDestroyTexture(gTextureStove);
	UDestroyTexture(gTextureBox);
	UDestroyTexture(gTextureOrange);
	UDestroyTexture(gTextureHat);
	UDestroyTexture (gTextureBottleTop2);
	UDestroyTexture (gTextureBottleLabel);
	UDestroyTexture (gTextureHatStrap);
	UDestroyTexture (gTextureContainerTop);

	//terminate program
	exit(EXIT_SUCCESS);
}


//initialize glfw, glew and create the window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
	//glfw initialize
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	//create window
	* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
	//if check for window creation
	if (*window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return false;
	}
	glfwMakeContextCurrent(*window);
	glfwSetFramebufferSizeCallback(*window, UResizeWindow);
	glfwSetCursorPosCallback(*window, UMousePositionCallback);

	//glew initialize
	glewExperimental = GL_TRUE;
	GLenum GlewInitResult = glewInit();

	//mouse capture
	glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	if (GLEW_OK != GlewInitResult)
	{
		std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
		return false;
	}

	//openGL version
	cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

	return true;
}


//function for input command
void UProcessInput(GLFWwindow* window) {


	//esc key
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {

		glfwSetWindowShouldClose(window, true);
	}

	//p key
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
		perspective = true;
	}
	//o key (turns on ortho)
	if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS) {
		perspective = false;
	}

	if (perspective) {
		//w key
		if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {

			gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
		}
		//s key
		if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {

			gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
		}
		//a key
		if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {

			gCamera.ProcessKeyboard(LEFT, gDeltaTime);
		}
		//d key
		if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {

			gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
		}

		//q key
		if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {

			gCamera.ProcessKeyboard(UP, gDeltaTime);
		}
		//e key
		if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {

			gCamera.ProcessKeyboard(DOWN, gDeltaTime);
		}
	}

}
//process mouse movements
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
	if (gFirstMouse)
	{
		gLastX = xpos;
		gLastY = ypos;
		gFirstMouse = false;
	}

	float xoffset = xpos - gLastX;
	float yoffset = gLastY - ypos;

	gLastX = xpos;
	gLastY = ypos;

	gCamera.ProcessMouseMovement(xoffset, yoffset);
}

// mouse scroll
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
	gCamera.ProcessMouseScroll(yoffset);
}

// mouse buttons
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
	switch (button)
	{
	case GLFW_MOUSE_BUTTON_LEFT:
	{
		if (action == GLFW_PRESS)
			cout << "Left mouse button pressed" << endl;
		else
			cout << "Left mouse button released" << endl;
	}
	break;

	case GLFW_MOUSE_BUTTON_MIDDLE:
	{
		if (action == GLFW_PRESS)
			cout << "Middle mouse button pressed" << endl;
		else
			cout << "Middle mouse button released" << endl;
	}
	break;

	case GLFW_MOUSE_BUTTON_RIGHT:
	{
		if (action == GLFW_PRESS)
			cout << "Right mouse button pressed" << endl;
		else
			cout << "Right mouse button released" << endl;
	}
	break;

	default:
		cout << "Mouse button not recognized" << endl;
		break;
	}
}

//function for window size change
void UResizeWindow(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);
}

void URender()
{
	GLint modelLoc;
	GLint viewLoc;
	GLint projLoc;

	GLint viewPosLoc;
	//ambient light
	GLint ambStrLoc;
	GLint ambColLoc;
	//first light
	GLint light1ColLoc;
	GLint light1PosLoc;
	//second light
	GLint light2ColLoc;
	GLint light2PosLoc;

	//object color
	GLint objColLoc;
	//specular light 1
	GLint specInt1Loc;
	GLint highlghtSz1Loc;
	//specular light 2
	GLint specInt2Loc;
	GLint highlghtSz2Loc;

	//has texture
	GLint uHasTextureLoc;
	bool ubHasTextureVal;
	//set for modeling light or object
	glm::mat4 scale;
	glm::mat4 rotation;
	glm::mat4 rotation1;
	glm::mat4 rotation2;
	glm::mat4 translation;
	glm::mat4 model;

	glm::mat4 view;
	glm::mat4 projection;

	//z-depth
	glEnable(GL_DEPTH_TEST);

	//blending
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	//clear frame
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	view = gCamera.GetViewMatrix();

	if (perspective) {
		projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
	}
	else {
		gCamera.OrthoView();
		view = gCamera.GetViewMatrix();
		projection = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f);
	}
	//set shader use
	glUseProgram(gProgramId);


	

	//retrieves and passes transform matrices to shader program
	modelLoc = glGetUniformLocation(gProgramId, "model");
	viewLoc = glGetUniformLocation(gProgramId, "view");
	projLoc = glGetUniformLocation(gProgramId, "projection");
	viewPosLoc = glGetUniformLocation(gProgramId, "viewPosition");
	ambStrLoc = glGetUniformLocation(gProgramId, "ambientStrength");
	ambColLoc = glGetUniformLocation(gProgramId, "ambientColor");

	light1ColLoc = glGetUniformLocation(gProgramId, "light1Color");
	light1PosLoc = glGetUniformLocation(gProgramId, "light1Position");

	light2ColLoc = glGetUniformLocation(gProgramId, "light2Color");
	light2PosLoc = glGetUniformLocation(gProgramId, "light2Position");

	GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");

	glm::vec2 gUVScale=glm::vec2(1.0f, 1.0f);
	glm::vec2 gUVScaleTile = glm::vec2(3.0f, 3.0f);
	glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

	//trying to assign material properties
	GLfloat mat_ambient[] = { 0.0f, 0.0f, 0.0f, 1.0f };
	GLfloat mat_diffuse[] = { 0.8f, 0.8f, 0.8f, 1.0f };
	GLfloat mat_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat mat_emission[] = { 0.0f, 0.0f, 0.0f, 1.0f };
	GLfloat mat_shininess = 50.0f;

	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	glMaterialf(GL_FRONT, GL_SHININESS, mat_shininess);

	//enable lighting
	glEnable(GL_LIGHTING);
	glEnable(GL_FRONT);

	//object color
	objColLoc = glGetUniformLocation(gProgramId, "objectColor");

	//specular light 1
	specInt1Loc = glGetUniformLocation(gProgramId, "specularIntensity1");
	highlghtSz1Loc = glGetUniformLocation(gProgramId, "highlightSize1");

	//specular light 2
	specInt2Loc = glGetUniformLocation(gProgramId, "specularIntensity2");
	highlghtSz2Loc = glGetUniformLocation(gProgramId, "highlightSize2");

	//texture
	uHasTextureLoc = glGetUniformLocation(gProgramId, "ubHasTexture");

	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	//set the camera view location
	glUniform3f(viewPosLoc, gCamera.Position.x, gCamera.Position.y, gCamera.Position.z);
	//ambient strength
	glUniform1f(ambStrLoc, 0.4f);
	//ambient color
	glUniform3f(ambColLoc, 0.2f, 0.2f, 0.2f);

	//light1
	glUniform3f(light1ColLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(light1PosLoc, 0.0f, 10.0f, 15.0f);
	glUniform1f(specInt1Loc, 0.9f);
	glUniform1f(highlghtSz1Loc, 32.0f);

	//light2
	glUniform3f(light2ColLoc, 1.0f, 1.0f, 0.8f);
	glUniform3f(light2PosLoc, 0.0f, 10.0f, -10.0f);
	//specular intensity
	glUniform1f(specInt2Loc, 0.3f);
	//specular highlight size
	glUniform1f(highlghtSz2Loc, 6.0f);

	ubHasTextureVal = true;
	glUniform1i(uHasTextureLoc, ubHasTextureVal);

	GLint objectColorLoc = glGetUniformLocation(gProgramId, "objectColor");

	GLuint multipleTexturesLoc = glGetUniformLocation(gProgramId, "multipleTextures");

	//plane----------------------------------------------------------------
	//activate the vbos
	glBindVertexArray(meshes.gPlaneMesh.vao);

	//scale it
	scale = glm::scale(glm::vec3(6.0f, 1.0f, 4.0f));
	//rotate it
	rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
	//position it
	translation = glm::translate(glm::vec3(0.0f, -0.0001f, 0.0f));

	//model matrix (right to left)
	model = translation * rotation * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glUniform1i(multipleTexturesLoc, extraTex = false);

	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 2);
	
	//light1
	glUniform3f(light1ColLoc, 1.0f, 1.0f, 0.7f);
	glUniform3f(light1PosLoc, 0.0f, 10.0f, 15.0f);
	glUniform1f(specInt1Loc, 0.9f);
	glUniform1f(highlghtSz1Loc, 50.0f);

	//light2
	glUniform3f(light2ColLoc, 1.0f, 1.0f, 0.8f);
	glUniform3f(light2PosLoc, 0.0f, 10.0f, -10.0f);
	//specular intensity
	glUniform1f(specInt2Loc, 0.3f);
	//specular highlight size
	glUniform1f(highlghtSz2Loc, 10.0f);

	glProgramUniform4f(gProgramId, objectColorLoc, 1.0f, 1.0f, 1.0f, 1.0f);
	//draw it
	glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	glBindVertexArray(0);
	//box------------------------------------------------------------------
	//activate the vbos
	glBindVertexArray(meshes.gBoxMesh.vao);

	//scale it
	scale = glm::scale(glm::vec3(2.0f, 2.0f, 2.0f));
	//rotate it
	rotation = glm::rotate(0.0f, glm::vec3(0.0, 1.0f, 0.0f));
	//position it
	translation = glm::translate(glm::vec3(1.0f, 1.0f, 1.5f));

	//model matrix
	model = translation * rotation * scale;

	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	//glProgramUniform4f(gProgramId, objectColorLoc, 1.0f, 0.5f, 0.0f, 1.0f);
	//light1
	glUniform3f(light1ColLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(light1PosLoc, 0.0f, 10.0f, 15.0f);
	glUniform1f(specInt1Loc, 1.0f);
	glUniform1f(highlghtSz1Loc, 32.0f);

	//light2
	glUniform3f(light2ColLoc, 1.0f, 1.0f, 0.8f);
	glUniform3f(light2PosLoc, 0.0f, 10.0f, -10.0f);
	//specular intensity
	glUniform1f(specInt2Loc, 0.5f);
	//specular highlight size
	glUniform1f(highlghtSz2Loc, 6.0f);

	glUniform1i(multipleTexturesLoc, extraTex = true);

	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 3);
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture2"), 0);

	//draw it
	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	glBindVertexArray(0);

	//box Top---------------------------------------------------------------
	//activate the vbos
	glBindVertexArray(meshes.gBoxMesh.vao);

	//scale it
	scale = glm::scale(glm::vec3(2.001f, 0.15f, 2.001f));
	//rotate it
	rotation = glm::rotate(0.0f, glm::vec3(0.0, 1.0f, 0.0f));
	//position it
	translation = glm::translate(glm::vec3(1.0f, 2.0f, 1.5f));

	//model matrix
	model = translation * rotation * scale;

	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	//glProgramUniform4f(gProgramId, objectColorLoc, 1.0f, 0.5f, 0.0f, 1.0f);

	//light1
	glUniform3f(light1ColLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(light1PosLoc, 0.0f, 10.0f, 15.0f);
	glUniform1f(specInt1Loc, 0.2f);
	glUniform1f(highlghtSz1Loc, 32.0f);

	//light2
	glUniform3f(light2ColLoc, 1.0f, 1.0f, 0.8f);
	glUniform3f(light2PosLoc, 0.0f, 10.0f, -10.0f);
	//specular intensity
	glUniform1f(specInt2Loc, 0.1f);
	//specular highlight size
	glUniform1f(highlghtSz2Loc, 6.0f);

	glUniform1i(multipleTexturesLoc, extraTex = false);

	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 9);

	//draw it
	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	glBindVertexArray(0);
	//Rectangle---------------------------------------------------------------
	//activate the vbos
	glBindVertexArray(meshes.gBoxMesh.vao);

	//scale it
	scale = glm::scale(glm::vec3(2.0f, 4.0f, 2.0f));
	//rotate it
	rotation = glm::rotate(0.0f, glm::vec3(0.0, 1.0f, 0.0f));
	//position it
	translation = glm::translate(glm::vec3(0.0f, 2.0f, -0.5f));

	//model matrix
	model = translation * rotation * scale;

	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	//glProgramUniform4f(gProgramId, objectColorLoc, 1.0f, 0.0f, 0.0f, 1.0f);

	//light1
	glUniform3f(light1ColLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(light1PosLoc, 0.0f, 10.0f, 15.0f);
	glUniform1f(specInt1Loc, 1.0f);
	glUniform1f(highlghtSz1Loc, 32.0f);

	//light2
	glUniform3f(light2ColLoc, 1.0f, 1.0f, 0.8f);
	glUniform3f(light2PosLoc, 0.0f, 10.0f, -10.0f);
	//specular intensity
	glUniform1f(specInt2Loc, 0.3f);
	//specular highlight size
	glUniform1f(highlghtSz2Loc, 6.0f);

	glUniform1i(multipleTexturesLoc, extraTex = true);

	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 3);
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture2"), 0);

	//draw it
	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	glBindVertexArray(0);

	//Rectangle Top-----------------------------------------------------------
	//activate the vbos
	glBindVertexArray(meshes.gBoxMesh.vao);

	//scale it
	scale = glm::scale(glm::vec3(2.001f, 0.15f, 2.001f));
	//rotate it
	rotation = glm::rotate(0.0f, glm::vec3(0.0, 1.0f, 0.0f));
	//position it
	translation = glm::translate(glm::vec3(0.0f, 4.0f, -0.5f));

	//model matrix
	model = translation * rotation * scale;

	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	//glProgramUniform4f(gProgramId, objectColorLoc, 1.0f, 0.0f, 0.0f, 1.0f);

	//light1
	glUniform3f(light1ColLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(light1PosLoc, 0.0f, 10.0f, 15.0f);
	glUniform1f(specInt1Loc, 0.1f);
	glUniform1f(highlghtSz1Loc, 32.0f);

	//light2
	glUniform3f(light2ColLoc, 1.0f, 1.0f, 0.8f);
	glUniform3f(light2PosLoc, 0.0f, 10.0f, -10.0f);
	//specular intensity
	glUniform1f(specInt2Loc, 0.3f);
	//specular highlight size
	glUniform1f(highlghtSz2Loc, 6.0f);

	glUniform1i(multipleTexturesLoc, extraTex = false);

	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 9);


	//draw it
	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	glBindVertexArray(0);

	//bottle--------------------------------------------------------------------
	//activate vbos in mesh for cylinders
	glBindVertexArray(meshes.gCylinderMesh.vao);

	//scale it
	scale = glm::scale(glm::vec3(0.5f, 3.0f, 0.5f));
	//rotate it
	rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
	//position it
	translation = glm::translate(glm::vec3(-2.0f, 0.0f, 0.5f));

	//model matrix (right to left)
	model = translation * rotation * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	//color
	//glProgramUniform4f(gProgramId, objectColorLoc, 1.0f, 0.0f, 1.0f, 1.0f);

	//light1
	glUniform3f(light1ColLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(light1PosLoc, 0.0f, 10.0f, 15.0f);
	glUniform1f(specInt1Loc, 0.9f);
	glUniform1f(highlghtSz1Loc, 45.0f);

	//light2
	glUniform3f(light2ColLoc, 1.0f, 0.8f, 0.8f);
	glUniform3f(light2PosLoc, 0.0f, 10.0f, -10.0f);
	//specular intensity
	glUniform1f(specInt2Loc, 0.5f);
	//specular highlight size
	glUniform1f(highlghtSz2Loc, 6.0f);

	glUniform1i(multipleTexturesLoc, extraTex = true);
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 3);
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture2"), 0);


	//draw the triangles
	glDrawArrays(GL_TRIANGLE_FAN, 0, 36);
	glDrawArrays(GL_TRIANGLE_FAN, 36, 36);

	//apply label
	glUniform1i(multipleTexturesLoc, extraTex = true);
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 3);
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture2"), 7);
	glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);

	glUniform1i(multipleTexturesLoc, extraTex = false);
	glBindVertexArray(0);
	//top+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//activate vbos in mesh for cylinders
	glBindVertexArray(meshes.gCylinderMesh.vao);

	//scale it
	scale = glm::scale(glm::vec3(0.2f, 0.7f, 0.2f));
	//rotate it
	rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
	//position it
	translation = glm::translate(glm::vec3(-2.0f, 3.0f, 0.5f));

	//model matrix (right to left)
	model = translation * rotation * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	//color
	//glProgramUniform4f(gProgramId, objectColorLoc, 1.0f, 0.0f, 1.0f, 1.0f);
	//extraTex = true;

	//light1
	glUniform3f(light1ColLoc, 1.0f, 1.0f, 0.9f);
	glUniform3f(light1PosLoc, 0.0f, 10.0f, 15.0f);
	glUniform1f(specInt1Loc, 0.9f);
	glUniform1f(highlghtSz1Loc, 45.0f);

	//light2
	glUniform3f(light2ColLoc, 1.0f, 1.0f, 0.8f);
	glUniform3f(light2PosLoc, 0.0f, 10.0f, -10.0f);
	//specular intensity
	glUniform1f(specInt2Loc, 0.5f);
	//specular highlight size
	glUniform1f(highlghtSz2Loc, 6.0f);

	glUniform1i(multipleTexturesLoc, extraTex = true);

	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 3);
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture2"), 1);

	//draw the triangles
	//bottom and around
	//omitted since it is not needed to make the model
	//glDrawArrays(GL_TRIANGLE_FAN, 0, 36);
	glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);

	//top
	glUniform1i(multipleTexturesLoc, extraTex = false);
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 6);
	glDrawArrays(GL_TRIANGLE_FAN, 36, 36);

	//deactiate the vao
	glBindVertexArray(0);
	extraTex = false;
	//orange--------------------------------------------------------------------------
	//activate vbos
	glBindVertexArray(meshes.gSphereMesh.vao);

	//scale it
	scale = glm::scale(glm::vec3(0.5f, 0.5f, 0.5f));
	//rotate it
	rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
	//position it
	translation = glm::translate(glm::vec3(-1.0f, 0.5f, 2.5f));
	//model matrix right to left
	model = translation * rotation * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	//light1
	glUniform3f(light1ColLoc, 1.0f, 1.0f, 0.9f);
	glUniform3f(light1PosLoc, 0.0f, 10.0f, 15.0f);
	glUniform1f(specInt1Loc, 0.5f);
	glUniform1f(highlghtSz1Loc, 40.0f);

	//light2
	glUniform3f(light2ColLoc, 1.0f, 1.0f, 0.8f);
	glUniform3f(light2PosLoc, 0.0f, 10.0f, -10.0f);
	//specular intensity
	glUniform1f(specInt2Loc, 0.1f);
	//specular highlight size
	glUniform1f(highlghtSz2Loc, 6.0f);

	glUniform1i(multipleTexturesLoc, extraTex = false);
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 4);

	//draw it
	glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	//deactivate vao
	glBindVertexArray(0);
	//hat brim--------------------------------------------------------------------
	//activate vbos in mesh for cylinders
	glBindVertexArray(meshes.gCylinderMesh.vao);

	//scale it
	scale = glm::scale(glm::vec3(2.7f, 0.01f, 2.7f));
	//rotate it
	rotation = glm::rotate(glm::radians(15.0f), glm::vec3(1.0f, 0.0f, 0.0f));
	rotation2 = glm::rotate(glm::radians(-40.0f), glm::vec3(0.0f, 0.0f, 1.0f));
	//position it
	translation = glm::translate(glm::vec3(1.0f, 3.6f, -0.5f));

	//model matrix (right to left)
	model = translation * rotation * rotation2 * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	//color
	//glProgramUniform4f(gProgramId, objectColorLoc, 1.0f, 0.0f, 1.0f, 1.0f);

	//light1
	glUniform3f(light1ColLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(light1PosLoc, 0.0f, 10.0f, 15.0f);
	glUniform1f(specInt1Loc, 0.99f);
	glUniform1f(highlghtSz1Loc, 32.0f);

	//light2
	glUniform3f(light2ColLoc, 1.0f, 1.0f, 0.8f);
	glUniform3f(light2PosLoc, 0.0f, 10.0f, -10.0f);
	//specular intensity
	glUniform1f(specInt2Loc, 0.5f);
	//specular highlight size
	glUniform1f(highlghtSz2Loc, 6.0f);

	glUniform1i(multipleTexturesLoc, extraTex = false);
	glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScaleTile));
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 5);

	//draw the triangles
	glDrawArrays(GL_TRIANGLE_FAN, 0, 36);
	glDrawArrays(GL_TRIANGLE_FAN, 36, 36);
	glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);

	glBindVertexArray(0);

	//hat top rim--------------------------------------------------------------------
	//activate vbos in mesh for cylinders 
	glBindVertexArray(meshes.gCylinderMesh.vao);

	//scale it
	scale = glm::scale(glm::vec3(1.4f, 1.0f, 1.4f));
	//rotate it
	rotation = glm::rotate(glm::radians(15.0f), glm::vec3(1.0f, 0.0f, 0.0f));
	rotation2 = glm::rotate(glm::radians(-40.0f), glm::vec3(0.0f, 0.0f, 1.0f));
	//position it
	translation = glm::translate(glm::vec3(1.0f, 3.6f, -0.5f));

	//model matrix (right to left)
	model = translation * rotation * rotation2 * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	//color
	//glProgramUniform4f(gProgramId, objectColorLoc, 1.0f, 0.0f, 1.0f, 1.0f);


	//light1
	glUniform3f(light1ColLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(light1PosLoc, 0.0f, 10.0f, 15.0f);
	glUniform1f(specInt1Loc, 0.99f);
	glUniform1f(highlghtSz1Loc, 32.0f);

	//light2
	glUniform3f(light2ColLoc, 1.0f, 1.0f, 0.8f);
	glUniform3f(light2PosLoc, 0.0f, 10.0f, -10.0f);
	//specular intensity
	glUniform1f(specInt2Loc, 0.5f);
	//specular highlight size
	glUniform1f(highlghtSz2Loc, 6.0f);

	glUniform1i(multipleTexturesLoc, extraTex = false);
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 5);
	//draw the triangles
	glDrawArrays(GL_TRIANGLE_FAN, 0, 36);
	glDrawArrays(GL_TRIANGLE_FAN, 36, 36);

	glUniform1i(multipleTexturesLoc, extraTex = true);
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 5);
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture2"), 8);

	glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);

	glBindVertexArray(0);
	//hat top----------------------------------------------------------------------
	//activate vbos
	glBindVertexArray(meshes.gSphereMesh.vao);

	//scale it
	scale = glm::scale(glm::vec3(1.41f, 0.8f, 1.41f));
	//rotate it
	rotation = glm::rotate(glm::radians(15.0f), glm::vec3(1.0f, 0.0f, 0.0f));
	rotation2 = glm::rotate(glm::radians(-40.0f), glm::vec3(0.0f, 0.0f, 1.0f));
	//position it
	translation = glm::translate(glm::vec3(1.71f, 4.4f, -0.28f));

	//model matrix (right to left)
	model = translation * rotation * rotation2 * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));


	//light1
	glUniform3f(light1ColLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(light1PosLoc, 0.0f, 10.0f, 15.0f);
	glUniform1f(specInt1Loc, 0.99f);
	glUniform1f(highlghtSz1Loc, 32.0f);

	//light2
	glUniform3f(light2ColLoc, 1.0f, 1.0f, 0.8f);
	glUniform3f(light2PosLoc, 0.0f, 10.0f, -10.0f);
	//specular intensity
	glUniform1f(specInt2Loc, 0.5f);
	//specular highlight size
	glUniform1f(highlghtSz2Loc, 6.0f);

	glUniform1i(multipleTexturesLoc, extraTex = false);
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 5);

	//draw it
	glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	//deactivate vao
	glBindVertexArray(0);
	//===========================================================================
	
	glfwSwapBuffers(gWindow); 
}

//clears mesh data
void UDestroyMesh(GLMesh& mesh)
{
	glDeleteVertexArrays(1, &mesh.vao);
	glDeleteBuffers(2, mesh.vbos);
}

//create shader
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
	//variables for link test
	int success = 0;
	char infoLog[512];

	//create the shader object
	programId = glCreateProgram();

	//create the vertex and fragment shaders
	GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
	GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

	//retrive shader source
	glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
	glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

	//compile vertex shader
	glCompileShader(vertexShaderId);

	//if check for vartex compile errors
	glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
	if (!success) {
		glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

		return false;
	}

	//compile fragment shader
	glCompileShader(fragmentShaderId);
	//if check for fragment compile errors
	glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
		std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

		return false;
	}

	//attach to program
	glAttachShader(programId, vertexShaderId);
	glAttachShader(programId, fragmentShaderId);

	//link shader
	glLinkProgram(programId);

	//if check for link errors
	glGetProgramiv(programId, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
		std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

		return false;
	}

	//use shader program
	glUseProgram(programId);

	return true;
}

void UDestroyShaderProgram(GLuint programId)
{
	glDeleteProgram(programId);
}

//Y axis starts aimed down so has to be flipped
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
	for (int j = 0; j < height / 2; ++j)
	{
		int index1 = j * width * channels;
		int index2 = (height - 1 - j) * width * channels;

		for (int i = width * channels; i > 0; --i)
		{
			unsigned char tmp = image[index1];
			image[index1] = image[index2];
			image[index2] = tmp;
			++index1;
			++index2;
		}
	}
}

//generate texture
bool UCreateTexture(const char* filename, GLuint& textureId)
{
	int width, height, channels;
	unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
	if (image)
	{
		flipImageVertically(image, width, height, channels);

		glGenTextures(1, &textureId);
		glBindTexture(GL_TEXTURE_2D, textureId);

		//set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		//set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (channels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (channels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			cout << "Not implemented to handle image with " << channels << " channels" << endl;
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0);

		return true;
	}

	//error
	return false;
}

//destroy shader data
void UDestroyTexture(GLuint textureId)
{
	glGenTextures(1, &textureId);
}

